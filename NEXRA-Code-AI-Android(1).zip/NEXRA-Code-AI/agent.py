from pathlib import Path
import json, subprocess, urllib.request, urllib.error, re, shlex, os

BASE = Path(__file__).resolve().parent
WORKSPACE = (BASE / "workspace").resolve()
WORKSPACE.mkdir(exist_ok=True)

SYSTEM = r"""You are NEXRA Code AI, a local coding agent. You can use tools to inspect and modify the user's project.
When a tool is needed, output exactly one JSON object and nothing else:
{"tool":"list_files","args":{}}
Available tools:
- list_files: {}
- read_file: {"path":"relative/path"}
- write_file: {"path":"relative/path","content":"full file content"}
- run_python: {"path":"relative.py"}
- run_lua: {"path":"relative.lua"}
- run_command: {"command":"pwd"}
- create_project: {"name":"folder","files":{"main.py":"print('hello')"}}
- finish: {"message":"user-facing answer"}
Rules: Use relative paths only. Never claim an action succeeded before tool output. Work only inside workspace. Prefer small steps. After tool output, decide next action. Never ask for secrets. Do not try to escape workspace or access Android private data. Do not run destructive commands. For commands, only use safe allowlisted commands. If you can answer without tools, use finish.
"""

ALLOWED = {"pwd", "ls", "find", "cat", "head", "tail", "wc", "python", "python3", "lua", "git", "mkdir"}

class CodingAgent:
    def __init__(self, base, config):
        self.base, self.config = base, config
        self.api = f"http://{config['llama_host']}:{config['llama_port']}/v1/chat/completions"

    def safe_path(self, rel):
        if not isinstance(rel, str) or not rel or Path(rel).is_absolute():
            raise ValueError("ต้องใช้ path แบบ relative ภายใน workspace")
        p = (WORKSPACE / rel).resolve()
        if p != WORKSPACE and WORKSPACE not in p.parents:
            raise ValueError("ไม่อนุญาตให้ออกจาก workspace")
        return p

    def ask_model(self, messages):
        body = {
            "model": "local-model",
            "messages": messages,
            "temperature": self.config.get("temperature", 0.2),
            "max_tokens": self.config.get("max_tokens", 1200)
        }
        req = urllib.request.Request(self.api, data=json.dumps(body).encode(), headers={"Content-Type":"application/json"})
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                data = json.loads(r.read())
            return data["choices"][0]["message"]["content"]
        except Exception as e:
            raise RuntimeError(f"ติดต่อ Local Model ไม่สำเร็จ: {e}. ตรวจว่า llama-server ทำงานอยู่")

    def execute(self, name, args):
        if name == "list_files":
            return "\n".join(p.relative_to(WORKSPACE).as_posix() for p in WORKSPACE.rglob("*") if p.is_file()) or "(workspace ว่าง)"
        if name == "read_file":
            p = self.safe_path(args["path"])
            return p.read_text(encoding="utf-8", errors="replace")[:20000]
        if name == "write_file":
            p = self.safe_path(args["path"])
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(args["content"], encoding="utf-8")
            return f"เขียนไฟล์แล้ว: {args['path']} ({p.stat().st_size} bytes)"
        if name == "create_project":
            namepart = args["name"]
            folder = self.safe_path(namepart)
            folder.mkdir(parents=True, exist_ok=True)
            created = []
            for rel, content in args["files"].items():
                p = self.safe_path(f"{namepart}/{rel}")
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content, encoding="utf-8")
                created.append(p.relative_to(WORKSPACE).as_posix())
            return "สร้างไฟล์แล้ว:\n" + "\n".join(created)
        if name in ("run_python", "run_lua"):
            rel = args["path"]
            p = self.safe_path(rel)
            if not p.is_file():
                return "ไม่พบไฟล์"
            cmd = ["python", str(p)] if name == "run_python" else ["lua", str(p)]
            return self._run(cmd)
        if name == "run_command":
            raw = args.get("command", "")
            parts = shlex.split(raw)
            if not parts or parts[0] not in ALLOWED:
                return "คำสั่งนี้ไม่อยู่ใน allowlist"
            if any(x in raw for x in (";", "&&", "||", "|", ">", "<", "`", "$(", "\n")):
                return "ไม่อนุญาต shell operators"
            # Commands run with workspace as cwd; path traversal arguments are blocked.
            for token in parts[1:]:
                if token.startswith("/") or ".." in Path(token).parts:
                    return "ไม่อนุญาต absolute path หรือ .."
            return self._run(parts)
        if name == "finish":
            return args.get("message", "")
        return "ไม่รู้จักเครื่องมือ"

    def _run(self, cmd):
        try:
            p = subprocess.run(cmd, cwd=WORKSPACE, capture_output=True, text=True, timeout=30)
            out = (p.stdout + ("\n[stderr]\n" + p.stderr if p.stderr else "")).strip()
            return f"exit={p.returncode}\n{out[:12000]}"
        except subprocess.TimeoutExpired:
            return "หยุดการรัน: เกินเวลา 30 วินาที"
        except FileNotFoundError:
            return f"ไม่พบคำสั่ง: {cmd[0]}"

    def run(self, user_message):
        messages = [{"role":"system","content":SYSTEM}, {"role":"user","content":user_message}]
        trace = []
        for _ in range(8):
            answer = self.ask_model(messages)
            match = re.search(r"\{.*\}", answer, re.S)
            if not match:
                return {"answer": answer, "trace": trace}
            try:
                call = json.loads(match.group(0))
            except json.JSONDecodeError:
                return {"answer": answer, "trace": trace}
            tool, args = call.get("tool"), call.get("args", {})
            if tool == "finish":
                return {"answer": args.get("message", ""), "trace": trace}
            result = self.execute(tool, args)
            trace.append({"tool": tool, "result": str(result)[:4000]})
            messages.append({"role":"assistant","content":answer})
            messages.append({"role":"user","content":"TOOL RESULT:\n" + str(result) + "\nเลือกขั้นตอนถัดไป หรือ finish"})
        return {"answer":"Agent หยุดหลังครบ 8 ขั้นตอนเพื่อป้องกันการทำงานวนซ้ำ", "trace":trace}
