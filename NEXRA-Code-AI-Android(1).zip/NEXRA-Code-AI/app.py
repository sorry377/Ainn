from pathlib import Path
import json
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from agent import CodingAgent, WORKSPACE

BASE = Path(__file__).resolve().parent
CONFIG = json.loads((BASE / "config.json").read_text())
app = FastAPI(title="NEXRA Code AI")
agent = CodingAgent(BASE, CONFIG)

class ChatRequest(BaseModel):
    message: str

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "web" / "index.html").read_text(encoding="utf-8")

@app.get("/api/files")
def files():
    out = []
    for p in sorted(WORKSPACE.rglob("*")):
        if p.is_file():
            out.append({"path": p.relative_to(WORKSPACE).as_posix(), "size": p.stat().st_size})
    return {"files": out}

@app.get("/api/read")
def read_file(path: str):
    try:
        p = agent.safe_path(path)
        if not p.is_file():
            raise HTTPException(404, "ไม่พบไฟล์")
        return {"path": path, "content": p.read_text(encoding="utf-8", errors="replace")}
    except ValueError as e:
        raise HTTPException(400, str(e))

@app.post("/api/chat")
def chat(req: ChatRequest):
    if not req.message.strip():
        raise HTTPException(400, "กรุณาพิมพ์คำสั่ง")
    try:
        return agent.run(req.message[:8000])
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/api/health")
def health():
    return {"ok": True, "workspace": str(WORKSPACE), "model_server": f"http://{CONFIG['llama_host']}:{CONFIG['llama_port']}"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=CONFIG["web_host"], port=CONFIG["web_port"])
