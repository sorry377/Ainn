#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")/.."
CFG=$(cat config.json)
MODEL=$(python -c "import json;print(json.load(open('config.json'))['model_path'])")
SERVER=$(python -c "import json;print(json.load(open('config.json'))['llama_server'])")
PORT=$(python -c "import json;print(json.load(open('config.json'))['llama_port'])")
CTX=$(python -c "import json;print(json.load(open('config.json'))['context_size'])")
[ -f "$MODEL" ] || { echo "ไม่พบ $MODEL กรุณาวางไฟล์ GGUF ก่อน"; exit 1; }
[ -x "$SERVER" ] || { echo "ไม่พบ llama-server กรุณารัน scripts/build_llama_cpp.sh"; exit 1; }
"$SERVER" -m "$MODEL" --host 127.0.0.1 --port "$PORT" -c "$CTX" -ngl 0
