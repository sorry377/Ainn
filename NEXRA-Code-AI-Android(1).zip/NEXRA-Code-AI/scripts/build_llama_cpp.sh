#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$HOME"
if [ ! -d llama.cpp ]; then git clone https://github.com/ggml-org/llama.cpp.git; fi
cd llama.cpp
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release -j2 --target llama-server
echo "Build เสร็จ: $HOME/llama.cpp/build/bin/llama-server"
