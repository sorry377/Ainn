#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg install -y python lua git cmake clang make pkg-config
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
mkdir -p models workspace
echo "ติดตั้งเสร็จแล้ว"
