# NEXRA Code AI — Android Local Coding Agent

AI Coding Agent แบบ Local-first สำหรับ Android ผ่าน Termux + เบราว์เซอร์
- ไม่ใช้ API Key และไม่ส่งโค้ดไปบริการ AI ภายนอก
- ใช้ `llama.cpp` แบบ OpenAI-compatible local server
- อ่าน/เขียนไฟล์ใน `workspace/`
- รัน Python, Lua และคำสั่งที่อนุญาต
- มี MCP stdio client แบบพื้นฐาน
- UI ภาษาไทย ใช้ผ่าน `http://127.0.0.1:8787`

> ต้องดาวน์โหลดโมเดล GGUF เอง และต้องมี RAM/พื้นที่เพียงพอ โมเดล 1B–3B แบบ Q4 เป็นจุดเริ่มต้นที่เหมาะกับมือถือระดับเริ่มต้น แต่คุณภาพการเขียนโค้ดอาจต่ำกว่าโมเดลใหญ่
> Android ไม่อนุญาตให้แอปทั่วไปเข้าถึงทุกไฟล์หรือ root โดยอัตโนมัติ ระบบนี้จำกัดการทำงานไว้ในโฟลเดอร์ workspace

## 1) ติดตั้งบน Android

1. ติดตั้ง Termux จาก F-Droid หรือ GitHub release ทางการ
2. เปิด Termux แล้วรัน:

```bash
pkg update -y && pkg upgrade -y
pkg install -y python git cmake clang make pkg-config lua
termux-setup-storage
```

3. แตก ZIP นี้ไว้ใน Termux เช่น `~/NEXRA-Code-AI`
4. เข้าโฟลเดอร์และติดตั้ง:

```bash
cd ~/NEXRA-Code-AI
bash scripts/install.sh
```

## 2) ติดตั้ง llama.cpp

วิธี build บน Android/Termux (อาจใช้เวลานานและต้องมีพื้นที่ว่าง):

```bash
bash scripts/build_llama_cpp.sh
```

ถ้า build สำเร็จ จะได้ `llama-server` ใน `~/llama.cpp/build/bin/llama-server`.

## 3) เพิ่มโมเดล GGUF

ดาวน์โหลดโมเดล instruct/code ที่มีไฟล์ `.gguf` จากแหล่งที่เชื่อถือได้ เช่น Hugging Face แล้ววางไว้ใน:

`~/NEXRA-Code-AI/models/model.gguf`

เลือกโมเดลที่ใบอนุญาตอนุญาตการใช้งานของคุณ และตรวจสอบ checksum/แหล่งที่มาก่อนรัน

## 4) เริ่มระบบ

เปิด Termux session แรก:

```bash
cd ~/NEXRA-Code-AI
bash scripts/start_model.sh
```

เปิด Termux session ที่สอง:

```bash
cd ~/NEXRA-Code-AI
source .venv/bin/activate
python app.py
```

เปิด Chrome บนมือถือไปที่ `http://127.0.0.1:8787`

## 5) การใช้งาน

ลองสั่ง:
- "สร้างโปรเจกต์ Python เครื่องคิดเลขในโฟลเดอร์ calculator"
- "อ่านไฟล์ main.py แล้วช่วยแก้บั๊ก"
- "รันไฟล์ main.py และสรุป error"
- "สร้างสคริปต์ Lua พิมพ์ Hello"

Agent จะเลือกเครื่องมือจาก JSON tool call ที่โมเดลส่งกลับ หากโมเดลไม่รองรับการเรียกเครื่องมือได้ดี ให้ใช้โมเดล instruct ที่ทำตาม JSON schema ได้ดีขึ้น

## 6) MCP

แก้ `mcp_servers.json` เพื่อเพิ่ม MCP server แบบ stdio ที่ติดตั้งใน Termux ตัวอย่าง:

```json
{
  "servers": [
    {
      "name": "example",
      "command": "python",
      "args": ["mcp_server.py"]
    }
  ]
}
```

MCP server ต้องเป็นโปรแกรมที่คุณติดตั้งและเชื่อถือเอง การเรียกเครื่องมือ MCP จะถูกแสดงในประวัติการทำงาน

## 7) ความปลอดภัย

- พื้นที่ทำงานจำกัดใน `workspace/`
- Terminal อนุญาตเฉพาะคำสั่งใน allowlist ใน `agent.py`
- ห้ามเปิดพอร์ตให้เครือข่ายสาธารณะ: เซิร์ฟเวอร์ bind เฉพาะ `127.0.0.1`
- อย่ารันโค้ดที่ไม่รู้แหล่งที่มา
- การรัน Python/Lua เป็นการรันโค้ดจริงภายใต้สิทธิ์ของ Termux ไม่ใช่ sandbox ระดับ OS
- MCP server ที่เพิ่มเองอาจเข้าถึงข้อมูลตามสิทธิ์ Termux ได้ ควรตรวจสอบก่อนใช้งาน

## 8) Build / ข้อจำกัด APK

เวอร์ชันนี้เป็นแอปเว็บ local ที่ติดตั้งเป็นไอคอนบนหน้าจอหลักได้ (Chrome > เมนู > Add to Home screen) โดยไม่ต้องมี API Key
การทำเป็น APK แท้ต้องมี Android SDK/Gradle และ WebView wrapper เพิ่มเติม ซึ่งไม่สามารถ build APK บน Android ทุกเครื่องได้โดยตรง โปรเจกต์นี้เลือกเส้นทาง Termux ที่ใช้งานได้จริงและแก้ไขง่ายก่อน

## Troubleshooting

- โมเดลโหลดไม่ขึ้น: ตรวจ path ใน `config.json`, RAM และ context size
- `llama-server` ไม่พบ: ตรวจว่าการ build llama.cpp สำเร็จ
- Python package ติดตั้งไม่ได้: `pkg upgrade -y` แล้วลอง `pip install -r requirements.txt`
- พอร์ตถูกใช้แล้ว: เปลี่ยน `port` ใน `config.json`
